import tkinter
from tkinter import *
import settings
import util
from game_logic import *

root = Tk()
root.config(background='grey')
root.geometry(f'{settings.width}x{settings.height}')
root.title('Minesweeper')
root.resizable(False, False)

top_frame = Frame(
    root,
    bg='black',
    width=util.width_prcnt(100),
    height=util.height_prcnt(20)
)
top_frame.place(x=0, y=0)
left_frame = Frame(
    root,
    bg='blue',
    width=util.width_prcnt(12.5),
    height=util.height_prcnt(80)
)
left_frame.place(x=0, y=util.height_prcnt(20))

main_frame = Frame(
    root,
    bg='yellow',
    width=util.width_prcnt(87.5),
    height=util.height_prcnt(80)
)
main_frame.place(x=util.width_prcnt(12.5),
                 y=util.height_prcnt(20)
                 )
hitung_button = tkinter.Button(root, text="Hitung", command= game_logic.main)
hitung_button.grid(row=7, column=0)

root.mainloop()


