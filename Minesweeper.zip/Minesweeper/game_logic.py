import random
import tkinter

def play():
    min_value = 0
    max_value = 9
    play = random.randint(min_value, max_value)
    return play


def win(player_scores):
    jumlah_pemain = jumlah_pemain_var.get()
    for i in range(jumlah_pemain):
        if player == 1:
            if player_scores[i] >= 10:
               win = 'you win'
            else:
               win = 'you lose'
            return win
        else:
            winner = max(player_scores)
            if player_scores[i] == winner:
                win = i+1
                return win



def coba():
    main = 'y'
    turn = 3
    q = 0
    for i in range(jumlah_pemain):
        while main == 'y' and turn > 0:           # TkInter tbl play
            game = [play() for d in range(3)]
            for a in range(3):
                if a == 2:
                    print(game[a])
                else:
                    print(game[a], end='')  # layar

            if game[0] == game[1] == game[2]:
                if game[0] == game[1] == game[2] == 7:
                    player_scores[i] += 25
                else:
                    player_scores[i] += 10
            elif game[0] == game[1] or game[0] == game[2] or game[1] == game[2]:
                player_scores[i] += 5
            else:
                player_scores[i] += 0
            main = input('Apakah anda ingin melanjutkan permainan ?(y/n): ')
            if main == 'y':
                turn -= 1

        main = 'y'
        turn = 5
        q = 0
        print(f'score = {player_scores[i]}')
    return player_scores[i]


def confirm_jumlah_pemain():
    jumlah_pemain = jumlah_pemain_var.get()
    if jumlah_pemain == 1:
        show_1_pemain()
    elif jumlah_pemain == 2:
        show_2_pemain()
    elif jumlah_pemain == 3:
        show_3_pemain()


def show_1_pemain():
    label_1_pemain.place(x=util.width_prcnt(90), y=util.height_prcnt(80))
    score_1_pemain.place(x=util.width_prcnt(450), y=util.height_prcnt(80))




