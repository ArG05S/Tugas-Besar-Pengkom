import settings

def height_prcnt(prcnt):
    return (settings.height / 100) * prcnt

def width_prcnt(prcnt):
    return (settings.width / 100) * prcnt

print(width_prcnt(10))